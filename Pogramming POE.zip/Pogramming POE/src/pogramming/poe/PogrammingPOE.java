import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;

public class LoginSystem {
    
    static ArrayList<User> users = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);
    
    public static void main(String[] args) {
        while (true) {
            System.out.println("\n1. Register\n2. Login\n3. Exit");
            System.out.print("Option: ");
            int option = sc.nextInt();
            sc.nextLine(); // Clear buffer
            
            if (option == 1) {
                // Register user
                System.out.print("Username: ");
                String username = sc.nextLine();
                
                System.out.print("Password: ");
                String password = sc.nextLine();
                
                System.out.print("Cell phone (with country code, e.g. +271234567890): ");
                String cellphone = sc.nextLine();
                
                System.out.print("First name: ");
                String firstName = sc.nextLine();
                
                System.out.print("Last name: ");
                String lastName = sc.nextLine();
                
                Login login = new Login();
                String regResult = login.registerUser(username, password, cellphone, firstName, lastName);
                System.out.println(regResult);
                
            } else if (option == 2) {
                // Login user
                System.out.print("Username: ");
                String username = sc.nextLine();
                
                System.out.print("Password: ");
                String password = sc.nextLine();
                
                Login login = new Login();
                boolean loginSuccess = login.loginUser(username, password);
                System.out.println(login.returnLoginStatus(loginSuccess));
                
            } else if (option == 3) {
                System.out.println("Goodbye!");
                break;
            }
        }
    }
}

class Login {
    // Check if username format is valid
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }
    
    // Check if password meets complexity requirements
    public boolean checkPasswordComplexity(String password) {
        if (password.length() < 8) {
            return false;
        }
        
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
        
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasCapital = true;
            } else if (Character.isDigit(c)) {
                hasNumber = true;
            } else if (!Character.isLetterOrDigit(c)) {
                hasSpecial = true;
            }
        }
        
        return hasCapital && hasNumber && hasSpecial;
    }
    
    // Check if cellphone number is valid
    public boolean checkCellPhoneNumber(String cellphone) {
        return Pattern.matches("\\+\\d+\\d{1,10}", cellphone);
    }
    
    // Register a new user
    public String registerUser(String username, String password, String cellphone, String firstName, String lastName) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters length";
        }
        
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted, please ensure that your password contains at least 8 characters, a capital letter, number and special character";
        }
        
        if (!checkCellPhoneNumber(cellphone)) {
            return "Cellphone number incorrectly formatted or does not contain international code";
        }
        
        // All validation passed, add the user
        User newUser = new User(username, password, cellphone, firstName, lastName);
        LoginSystem.users.add(newUser);
        
        return "Registration successful!";
    }
    
    // Login a user
    public boolean loginUser(String username, String password) {
        for (User user : LoginSystem.users) {
            if (user.username.equals(username) && user.password.equals(password)) {
                return true;
            }
        }
        return false;
    }
    
    // Return login status message
    public String returnLoginStatus(boolean loginSuccessful) {
        if (loginSuccessful) {
            return "Welcome, it is great to see you again";
        } else {
            return "Username or password incorrect, please try again";
        }
    }
}

class User {
    String username, password, cellphone, firstName, lastName;
    
    User(String username, String password, String cellphone, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.cellphone = cellphone;
        this.firstName = firstName;
        this.lastName = lastName;
    }
}
