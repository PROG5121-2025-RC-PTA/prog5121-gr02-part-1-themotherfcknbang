package LoginSystem;

import java.util.ArrayList;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

public class LoginSystem {
    
    static ArrayList<User> users = new ArrayList<>();
    
    public static void main(String[] args) {
        // Add sample user for testing
        Login login = new Login();
        login.registerUser("user_1", "Password1!", "+271234567890", "John", "Doe");
        
        boolean running = true;
        while (running) {
            try {
                String[] options = {"Register", "Login", "Exit"};
                int option = JOptionPane.showOptionDialog(
                    null,
                    "Choose an option:",
                    "Login System",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    options,
                    options[0]
                );
                
                switch (option) {
                    case 0 -> registerMenu(login);
                    case 1 -> loginMenu(login);
                    case 2, JOptionPane.CLOSED_OPTION -> {
                        JOptionPane.showMessageDialog(null, "Goodbye!");
                        running = false;
                    }
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(
                    null,
                    "An error occurred: " + e.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }
    
    // Handle registration menu
    private static void registerMenu(Login login) {
        String username = JOptionPane.showInputDialog(
            null,
            "Username (must contain _ and be max 5 chars):",
            "Registration",
            JOptionPane.QUESTION_MESSAGE
        );
        
        if (username == null) return; // User cancelled
        
        String password = JOptionPane.showInputDialog(
            null,
            "Password (min 8 chars with capital, number, special char):",
            "Registration",
            JOptionPane.QUESTION_MESSAGE
        );
        
        if (password == null) return; // User cancelled
        
        String cellphone = JOptionPane.showInputDialog(
            null,
            "Cell phone (with country code, e.g. +271234567890):",
            "Registration",
            JOptionPane.QUESTION_MESSAGE
        );
        
        if (cellphone == null) return; // User cancelled
        
        String firstName = JOptionPane.showInputDialog(
            null,
            "First name:",
            "Registration",
            JOptionPane.QUESTION_MESSAGE
        );
        
        if (firstName == null) return; // User cancelled
        
        String lastName = JOptionPane.showInputDialog(
            null,
            "Last name:",
            "Registration",
            JOptionPane.QUESTION_MESSAGE
        );
        
        if (lastName == null) return; // User cancelled
        
        String result = login.registerUser(username, password, cellphone, firstName, lastName);
        JOptionPane.showMessageDialog(
            null,
            result,
            "Registration Result",
            result.contains("successful") ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.WARNING_MESSAGE
        );
    }
    
    // Handle login menu
    private static void loginMenu(Login login) {
        String username = JOptionPane.showInputDialog(
            null,
            "Username:",
            "Login",
            JOptionPane.QUESTION_MESSAGE
        );
        
        if (username == null) return; // User cancelled
        
        String password = JOptionPane.showInputDialog(
            null,
            "Password:",
            "Login",
            JOptionPane.QUESTION_MESSAGE
        );
        
        if (password == null) return; // User cancelled
        
        boolean loginSuccess = login.loginUser(username, password);
        JOptionPane.showMessageDialog(
            null,
            login.returnLoginStatus(loginSuccess),
            "Login Result",
            loginSuccess ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.ERROR_MESSAGE
        );
        
        if (loginSuccess) {
            // Find the logged-in user and show user menu
            for (User user : users) {
                if (user.getUsername().equals(username)) {
                    userMenu(login, user);
                    break;
                }
            }
        }
    }
    
    // User menu after successful login
    private static void userMenu(Login login, User currentUser) {
        String[] options = {"View Profile", "Logout"};
        int choice = JOptionPane.showOptionDialog(
            null,
            "Welcome " + currentUser.getFirstName() + "! What would you like to do?",
            "User Menu",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.PLAIN_MESSAGE,
            null,
            options,
            options[0]
        );
        
        if (choice == 0) {
            // View profile
            JOptionPane.showMessageDialog(
                null,
                "User Profile:\n" +
                "Username: " + currentUser.getUsername() + "\n" +
                "Name: " + currentUser.getFirstName() + " " + currentUser.getLastName() + "\n" +
                "Phone: " + currentUser.getCellphone(),
                "User Profile",
                JOptionPane.INFORMATION_MESSAGE
            );
        }
        // For choice 1 or closed window, we simply return to main menu
    }
}

class Login {
    // Check if username format is valid
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }
    
    // Check if password meets complexity requirements
    public boolean checkPasswordComplexity(String password) {
        if (password.length() < 8) {
            return false;
        }
        
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
        
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasCapital = true;
            } else if (Character.isDigit(c)) {
                hasNumber = true;
            } else if (!Character.isLetterOrDigit(c)) {
                hasSpecial = true;
            }
        }
        
        return hasCapital && hasNumber && hasSpecial;
    }
    
    // Check if cellphone number is valid
    public boolean checkCellPhoneNumber(String cellphone) {
        return Pattern.matches("\\+\\d+", cellphone);
    }
    
    // Register a new user
    public String registerUser(String username, String password, String cellphone, String firstName, String lastName) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters length";
        }
        
        // Check if username already exists
        for (User user : LoginSystem.users) {
            if (user.getUsername().equals(username)) {
                return "Username already exists! Please choose a different username.";
            }
        }
        
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted, please ensure that your password contains at least 8 characters, a capital letter, number and special character";
        }
        
        if (!checkCellPhoneNumber(cellphone)) {
            return "Cellphone number incorrectly formatted or does not contain international code";
        }
        
        // All validation passed, add the user
        User newUser = new User(username, password, cellphone, firstName, lastName);
        LoginSystem.users.add(newUser);
        
        return "Registration successful!";
    }
    
    // Login a user
    public boolean loginUser(String username, String password) {
        for (User user : LoginSystem.users) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                return true;
            }
        }
        return false;
    }
    
    // Return login status message
    public String returnLoginStatus(boolean loginSuccessful) {
        if (loginSuccessful) {
            return "Welcome, it is great to see you again";
        } else {
            return "Username or password incorrect, please try again";
        }
    }
}

class User {
    private final String username;
    private final String password;
    private final String cellphone;
    private final String firstName;
    private final String lastName;
    
    public User(String username, String password, String cellphone, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.cellphone = cellphone;
        this.firstName = firstName;
        this.lastName = lastName;
    }
    
    // Getters
    public String getUsername() {
        return username;
    }
    
    public String getPassword() {
        return password;
    }
    
    public String getCellphone() {
        return cellphone;
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public String getLastName() {
        return lastName;
    }
}