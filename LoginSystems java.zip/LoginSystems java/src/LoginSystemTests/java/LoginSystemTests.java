package LoginSystemTests.java;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane; 

public class LoginSystemTests {
    
    // Test setup - populate sample data
    private static void setupTestData() {
        LoginSystem.users.clear();
        LoginSystem.storedMessages.clear();
        LoginSystem.disregardedMessages.clear();
        LoginSystem.sentMessages.clear();
        LoginSystem.messageHashes.clear();
        LoginSystem.messageIDs.clear();
        LoginSystem.messageCounter = 1;
        
        // Add test user
        Login login = new Login();
        login.registerUser("user_1", "Password1!", "+271234567890", "John", "Doe");
        
        // Set current user
        for (User user : LoginSystem.users) {
            if (user.getUsername().equals("user_1")) {
                LoginSystem.currentUser = user;
                break;
            }
        }
        
        // Populate test messages
        LoginSystem.populateSampleMessages();
    }
    
    // Test 1: Sent messages array correctly populated
    public static void testSentMessagesPopulated() {
        System.out.println("Test 1: Sent Messages Array");
        setupTestData();
        
        System.out.println("Sent messages found:");
        for (Message msg : LoginSystem.sentMessages) {
            System.out.println("- " + msg.getContent());
        }
        
        boolean test1 = false, test4 = false;
        for (Message msg : LoginSystem.sentMessages) {
            if (msg.getContent().equals("Did you get the cake?")) test1 = true;
            if (msg.getContent().equals("It is dinner time!!")) test4 = true;
        }
        
        System.out.println(test1 && test4 ? "PASS" : "FAIL");
        System.out.println();
    }
    
    // Test 2: Display longest message
    public static void testLongestMessage() {
        System.out.println("Test 2: Longest Message");
        setupTestData();
        
        String longest = "";
        for (Message msg : LoginSystem.storedMessages) {
            if (msg.getContent().length() > longest.length()) {
                longest = msg.getContent();
            }
        }
        
        System.out.println("Longest message: " + longest);
        boolean pass = longest.equals("Where are you? You are late! I have asked you to be on time");
        System.out.println(pass ? "PASS" : "FAIL");
        System.out.println();
    }
    
    // Test 3: Search for message ID
    public static void testSearchMessageByID() {
        System.out.println("Test 3: Search by Message ID");
        setupTestData();
        
        String found = "";
        for (Message msg : LoginSystem.storedMessages) {
            if (msg.getMessageID().equals("MSG004")) {
                found = msg.getContent();
                break;
            }
        }
        
        System.out.println("Message found: " + found);
        boolean pass = found.equals("It is dinner time!!");
        System.out.println(pass ? "PASS" : "FAIL");
        System.out.println();
    }
    
    // Test 4: Search messages by recipient
    public static void testSearchMessagesByRecipient() {
        System.out.println("Test 4: Search by Recipient");
        setupTestData();
        
        List<String> found = new ArrayList<>();
        for (Message msg : LoginSystem.storedMessages) {
            if (msg.getRecipient().equals("+27838884567")) {
                found.add(msg.getContent());
            }
        }
        
        System.out.println("Messages to +27838884567:");
        for (String content : found) {
            System.out.println("- " + content);
        }
        
        boolean pass = found.size() == 2 && 
                      found.contains("Where are you? You are late! I have asked you to be on time") &&
                      found.contains("Ok, I am leaving without you");
        System.out.println(pass ? "PASS" : "FAIL");
        System.out.println();
    }
    
    // Test 5: Delete message by hash
    public static void testDeleteMessageByHash() {
        System.out.println("Test 5: Delete by Hash");
        setupTestData();
        
        String targetMessage = "Where are you? You are late! I have asked you to be on time";
        Message toDelete = null;
        
        for (Message msg : LoginSystem.storedMessages) {
            if (msg.getContent().equals(targetMessage)) {
                toDelete = msg;
                break;
            }
        }
        
        if (toDelete != null) {
            LoginSystem.disregardedMessages.add(toDelete);
            LoginSystem.storedMessages.remove(toDelete);
            System.out.println("Message successfully deleted: " + targetMessage);
            System.out.println("PASS");
        } else {
            System.out.println("FAIL - Message not found");
        }
        System.out.println();
    }
    
    // Test 6: Display report
    public static void testDisplayReport() {
        System.out.println("Test 6: Display Report");
        setupTestData();
        
        System.out.println("SENT MESSAGES REPORT:");
        int count = 0;
        for (Message msg : LoginSystem.sentMessages) {
            count++;
            System.out.println("Hash: " + msg.getMessageHash());
            System.out.println("Recipient: " + msg.getRecipient());
            System.out.println("Message: " + msg.getContent());
            System.out.println("---");
        }
        
        boolean pass = count == 2;
        System.out.println(pass ? "PASS" : "FAIL");
        System.out.println();
    }
    
    // Run all tests
    public static void main(String[] args) {
        System.out.println("RUNNING UNIT TESTS");
        System.out.println("==================");
        
        testSentMessagesPopulated();
        testLongestMessage();
        testSearchMessageByID();
        testSearchMessagesByRecipient();
        testDeleteMessageByHash();
        testDisplayReport();
        
        System.out.println("TESTS COMPLETED");
    }

    private static class LoginSystem {

        private static Iterable<Message> sentMessages;
        private static Iterable<Message> storedMessages;
        private static int messageCounter;

        private static void populateSampleMessages() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        public LoginSystem() {
        }

        private static class disregardedMessages {

            private static void add(Message toDelete) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }

            private static void clear() {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }

            public disregardedMessages() {
            }
        }

        private static class users {

            private static void clear() {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }

            public users() {
            }
        }

        private static class messageHashes {

            private static void clear() {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }

            public messageHashes() {
            }
        }

        private static class messageIDs {

            private static void clear() {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }

            public messageIDs() {
            }
        }
    }

    private static class Message {

        public Message() {
        }

        private String getContent() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private Object getMessageID() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private Object getRecipient() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }

        private String getMessageHash() {
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }
}

