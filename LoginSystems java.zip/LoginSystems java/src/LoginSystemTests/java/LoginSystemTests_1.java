package LoginSystemTests.java; 

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

// User class
class User {
    private final String username;
    private final String password;
    private final String phoneNumber;
    private final String firstName;
    private final String lastName;
    
    public User(String username, String password, String phoneNumber, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.firstName = firstName;
        this.lastName = lastName;
    }
    
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getPhoneNumber() { return phoneNumber; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
}

// Message class
class Message {
    private final String messageID;
    private final String content;
    private final String recipient;
    private final String messageHash;
    private final String sender;
    
    public Message(String messageID, String content, String recipient, String sender) {
        this.messageID = messageID;
        this.content = content;
        this.recipient = recipient;
        this.sender = sender;
        this.messageHash = generateHash(content);
    }
    
    private String generateHash(String content) {
        return "HASH_" + Math.abs(content.hashCode());
    }
    
    public String getMessageID() { return messageID; }
    public String getContent() { return content; }
    public String getRecipient() { return recipient; }
    public String getMessageHash() { return messageHash; }
    public String getSender() { return sender; }
}

// Login class
class Login {
    public boolean registerUser(String username, String password, String phoneNumber, String firstName, String lastName) {
        User user = new User(username, password, phoneNumber, firstName, lastName);
        LoginSystem.users.add(user);
        return true;
    }
}

// Main LoginSystem class
class LoginSystem {
    public static ArrayList<User> users = new ArrayList<>();
    public static ArrayList<Message> storedMessages = new ArrayList<>();
    public static ArrayList<Message> disregardedMessages = new ArrayList<>();
    public static ArrayList<Message> sentMessages = new ArrayList<>();
    public static ArrayList<String> messageHashes = new ArrayList<>();
    public static ArrayList<String> messageIDs = new ArrayList<>();
    public static int messageCounter = 1;
    public static User currentUser = null;
    
    public static void populateSampleMessages() {
        // Clear existing data
        storedMessages.clear();
        sentMessages.clear();
        messageHashes.clear();
        messageIDs.clear();
        
        // Sample stored messages (received)
        Message msg1 = new Message("MSG001", "Hello, how are you?", "+271234567890", "+27987654321");
        Message msg2 = new Message("MSG002", "Where are you? You are late! I have asked you to be on time", "+27838884567", "+271234567890");
        Message msg3 = new Message("MSG003", "Meeting at 3 PM", "+271234567890", "+27555123456");
        Message msg4 = new Message("MSG004", "It is dinner time!!", "+27838884567", "+271234567890");
        Message msg5 = new Message("MSG005", "Ok, I am leaving without you", "+27838884567", "+271234567890");
        
        storedMessages.add(msg1);
        storedMessages.add(msg2);
        storedMessages.add(msg3);
        storedMessages.add(msg4);
        storedMessages.add(msg5);
        
        // Sample sent messages
        Message sent1 = new Message("MSG006", "Did you get the cake?", "+27987654321", "+271234567890");
        Message sent2 = new Message("MSG007", "It is dinner time!!", "+27838884567", "+271234567890");
        
        sentMessages.add(sent1);
        sentMessages.add(sent2);
        
        // Populate hash and ID lists
        for (Message msg : storedMessages) {
            messageHashes.add(msg.getMessageHash());
            messageIDs.add(msg.getMessageID());
        }
        for (Message msg : sentMessages) {
            messageHashes.add(msg.getMessageHash());
            messageIDs.add(msg.getMessageID());
        }
        
        messageCounter = 8; // Next available counter
    }
}

// Test class
public class LoginSystemTests {
    
    // Test setup - populate sample data
    private static void setupTestData() {
        LoginSystem.users.clear();
        LoginSystem.storedMessages.clear();
        LoginSystem.disregardedMessages.clear();
        LoginSystem.sentMessages.clear();
        LoginSystem.messageHashes.clear();
        LoginSystem.messageIDs.clear();
        LoginSystem.messageCounter = 1;
        
        // Add test user
        Login login = new Login();
        login.registerUser("user_1", "Password1!", "+271234567890", "John", "Doe");
        
        // Set current user
        for (User user : LoginSystem.users) {
            if (user.getUsername().equals("user_1")) {
                LoginSystem.currentUser = user;
                break;
            }
        }
        
        // Populate test messages
        LoginSystem.populateSampleMessages();
    }
    
    // Test 1: Sent messages array correctly populated
    public static void testSentMessagesPopulated() {
        setupTestData();
        
        StringBuilder messages = new StringBuilder("Sent messages found:\n");
        for (Message msg : LoginSystem.sentMessages) {
            messages.append("- ").append(msg.getContent()).append("\n");
        }
        
        boolean test1 = false, test4 = false;
        for (Message msg : LoginSystem.sentMessages) {
            if (msg.getContent().equals("Did you get the cake?")) test1 = true;
            if (msg.getContent().equals("It is dinner time!!")) test4 = true;
        }
        
        messages.append("\nResult: ").append(test1 && test4 ? "PASS" : "FAIL");
        JOptionPane.showMessageDialog(null, messages.toString(), "Test 1: Sent Messages Array", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // Test 2: Display longest message
    public static void testLongestMessage() {
        setupTestData();
        
        String longest = "";
        for (Message msg : LoginSystem.storedMessages) {
            if (msg.getContent().length() > longest.length()) {
                longest = msg.getContent();
            }
        }
        
        boolean pass = longest.equals("Where are you? You are late! I have asked you to be on time");
        String result = "Longest message: " + longest + "\n\nResult: " + (pass ? "PASS" : "FAIL");
        JOptionPane.showMessageDialog(null, result, "Test 2: Longest Message", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // Test 3: Search for message ID
    public static void testSearchMessageByID() {
        setupTestData();
        
        String found = "";
        for (Message msg : LoginSystem.storedMessages) {
            if (msg.getMessageID().equals("MSG004")) {
                found = msg.getContent();
                break;
            }
        }
        
        boolean pass = found.equals("It is dinner time!!");
        String result = "Message found: " + found + "\n\nResult: " + (pass ? "PASS" : "FAIL");
        JOptionPane.showMessageDialog(null, result, "Test 3: Search by Message ID", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // Test 4: Search messages by recipient
    public static void testSearchMessagesByRecipient() {
        setupTestData();
        
        List<String> found = new ArrayList<>();
        for (Message msg : LoginSystem.storedMessages) {
            if (msg.getRecipient().equals("+27838884567")) {
                found.add(msg.getContent());
            }
        }
        
        StringBuilder result = new StringBuilder("Messages to +27838884567:\n");
        for (String content : found) {
            result.append("- ").append(content).append("\n");
        }
        
        boolean pass = found.size() == 2 && 
                      found.contains("Where are you? You are late! I have asked you to be on time") &&
                      found.contains("Ok, I am leaving without you");
        result.append("\nResult: ").append(pass ? "PASS" : "FAIL");
        JOptionPane.showMessageDialog(null, result.toString(), "Test 4: Search by Recipient", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // Test 5: Delete message by hash
    public static void testDeleteMessageByHash() {
        setupTestData();
        
        String targetMessage = "Where are you? You are late! I have asked you to be on time";
        Message toDelete = null;
        
        for (Message msg : LoginSystem.storedMessages) {
            if (msg.getContent().equals(targetMessage)) {
                toDelete = msg;
                break;
            }
        }
        
        String result;
        if (toDelete != null) {
            int confirm = JOptionPane.showConfirmDialog(null, 
                "Are you sure you want to delete this message?\n\n" + targetMessage, 
                "Confirm Delete", JOptionPane.YES_NO_OPTION);
            
            if (confirm == JOptionPane.YES_OPTION) {
                LoginSystem.disregardedMessages.add(toDelete);
                LoginSystem.storedMessages.remove(toDelete);
                result = "Message successfully deleted:\n" + targetMessage + "\n\nResult: PASS";
            } else {
                result = "Delete cancelled by user";
            }
        } else {
            result = "FAIL - Message not found";
        }
        
        JOptionPane.showMessageDialog(null, result, "Test 5: Delete by Hash", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // Test 6: Display report
    public static void testDisplayReport() {
        setupTestData();
        
        StringBuilder report = new StringBuilder("SENT MESSAGES REPORT:\n\n");
        int count = 0;
        for (Message msg : LoginSystem.sentMessages) {
            count++;
            report.append("Hash: ").append(msg.getMessageHash()).append("\n");
            report.append("Recipient: ").append(msg.getRecipient()).append("\n");
            report.append("Message: ").append(msg.getContent()).append("\n");
            report.append("---\n");
        }
        
        boolean pass = count == 2;
        report.append("\nResult: ").append(pass ? "PASS" : "FAIL");
        
        JOptionPane.showMessageDialog(null, report.toString(), "Test 6: Display Report", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // Run all tests
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "RUNNING UNIT TESTS\n==================", "Test Suite Started", JOptionPane.INFORMATION_MESSAGE);
        
        testSentMessagesPopulated();
        testLongestMessage();
        testSearchMessageByID();
        testSearchMessagesByRecipient();
        testDeleteMessageByHash();
        testDisplayReport();
        
        JOptionPane.showMessageDialog(null, "TESTS COMPLETED", "Test Suite Finished", JOptionPane.INFORMATION_MESSAGE);
        System.exit(0); // Close the application properly
    }
}